//
//  AuthService.swift
//  Smack
//
//  Created by DevPair11 on 13/09/2017.
//  Copyright © 2017 DevPair11. All rights reserved.
//

import Foundation
import Alamofire

class AuthService { //WE CAN ACCESS THESE VARIABLES ANYWHERE, SINGLETONS
    
    static let instance = AuthService()
    
    let defaults = UserDefaults.standard
    
    
    
    var isLoggedIn : Bool {
        get {
            return defaults.bool(forKey: LOGGED_IN_KEY)
            
        }
        set {
            defaults.set(newValue, forKey: LOGGED_IN_KEY)
        }
    }
    
    
    var authToken: String {
        get {
            return defaults.value(forKey: TOKEN_KEY) as! String
        }
        set {
            defaults.set(newValue, forKey: TOKEN_KEY)
            
        }
    }
    
    var UserEmail: String {
        get {
            return defaults.value(forKey: USER_EMAIL) as! String
        }
        set {
            defaults.set(newValue, forKey: USER_EMAIL)
            
        }
    }
    
    
    //WEB REQUEST ON XCODE
    
    func registerUser(email: String, password: String, completion: @escaping CompletionHandler) {
        
        let lowerCaseEmail = email.lowercased()
        let header = [
        "Content-Type": "application/json; charset=utf-8"
            
        ]
        let body: [String: Any] = [
            "email": lowerCaseEmail,
            "password": password]
        
        
        Alamofire.request(<#T##url: URLConvertible##URLConvertible#>, method: <#T##HTTPMethod#>, parameters: <#T##Parameters?#>, encoding: <#T##ParameterEncoding#>, headers: <#T##HTTPHeaders?#>)
        
        
    }
    
    
    
    
    
    
}
