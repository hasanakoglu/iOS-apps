//
//  Constants.swift
//  Smack
//
//  Created by DevPair11 on 12/09/2017.
//  Copyright © 2017 DevPair11. All rights reserved.
//

import Foundation

typealias CompletionHandler = (_ Success: Bool) -> ()


//url constants 
let BASE_URL = "https://chatychatchat1.herokuapp.com/



//segues
let TO_LOGIN = "toLogin" 
let TO_CREATE_ACCOUNT = "toCreateAccount" 
let UNWIND = "unwindToChannel" 


//USER DEFAULTS 
let TOKEN_KEY = "token"
let LOGGED_IN_KEY = "loggedIn"
let USER_EMAIL = "userEmsil"
