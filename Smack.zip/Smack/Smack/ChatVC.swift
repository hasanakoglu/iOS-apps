//
//  ChatVC.swift
//  Smack
//
//  Created by DevPair11 on 12/09/2017.
//  Copyright © 2017 DevPair11. All rights reserved.
//

import UIKit

class ChatVC: UIViewController {

    //outlets
    
    @IBOutlet weak var menuBtn: UIButton!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        menuBtn.addTarget(self.revealViewController(), action: #selector(SWRevealViewController.revealToggle(_:)), for: .touchUpInside)

        // Do any additional setup after loading the view.
        self.view.addGestureRecognizer(self.revealViewController().panGestureRecognizer())
        self.view.addGestureRecognizer(self.revealViewController().tapGestureRecognizer())

    }



}
