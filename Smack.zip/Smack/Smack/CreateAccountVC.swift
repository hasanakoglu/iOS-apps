//
//  CreateAccountVC.swift
//  Smack
//
//  Created by DevPair11 on 12/09/2017.
//  Copyright © 2017 DevPair11. All rights reserved.
//

import UIKit

class CreateAccountVC: UIViewController {

    @IBAction func closePressed(_ sender: Any) {
        performSegue(withIdentifier: UNWIND, sender: nil)
        
    }
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }



}
